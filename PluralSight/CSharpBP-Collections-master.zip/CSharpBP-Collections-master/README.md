# CSharpBP-Collections
Materials and starter files for the "C# Best Practices: Collections and Generics" Pluralsight course.

**NOTE: The `AcmeApp` sample code uses C# 6 and requires Visual Studio 2015.**

If you are using VS 2013, use the `AcmeApp-For VS2013` version of the sample code.
